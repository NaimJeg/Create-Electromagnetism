package com.electromagnetism.integration.cee.mixin;

import com.electromagnetism.integration.cee.electrical.CeeStepEvidence;
import com.george_vi.electroenergetics.simulation.SimulationResults;
import com.george_vi.electroenergetics.simulation.simulator.SimulationTicker;
import com.george_vi.electroenergetics.simulation.util.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.*;

/** Exact 9173792 worker boundary; required injections fail closed on incompatible bytecode. */
@Mixin(value = SimulationTicker.class, remap = false)
public abstract class SimulationEvidenceMixin {
    @Inject(method = "lambda$tick$1", at = @At("HEAD"))
    private void electromagnetism$begin(List<?> networks, Collection<?> nodes, long started,
            CallbackInfoReturnable<SimulationResults> cir) { CeeStepEvidence.begin(); }
    @Inject(method = "lambda$tick$1", at = @At("RETURN"))
    private void electromagnetism$finish(List<?> networks, Collection<?> nodes, long started,
            CallbackInfoReturnable<SimulationResults> cir) { CeeStepEvidence.finish(cir.getReturnValue()); }
    @Redirect(method = "lambda$tick$1", at = @At(value = "INVOKE", target = "Lcom/george_vi/electroenergetics/simulation/util/LUSolver;solve(Lcom/george_vi/electroenergetics/simulation/util/SparseMatrix;[D)[D"))
    private double[] electromagnetism$lu(SparseMatrix a, double[] b) { return CeeStepEvidence.solve(a, b, LUSolver::solve); }
    @Redirect(method = "lambda$tick$1", at = @At(value = "INVOKE", target = "Lcom/george_vi/electroenergetics/simulation/util/CholeskySolver;solve(Lcom/george_vi/electroenergetics/simulation/util/SparseMatrix;[D)[D"))
    private double[] electromagnetism$cholesky(SparseMatrix a, double[] b) { return CeeStepEvidence.solve(a, b, CholeskySolver::solve); }
}
