package com.electromagnetism.integration.cee.electrical;

import com.electromagnetism.core.model.*;
import com.george_vi.electroenergetics.foundation.nodes.InWorldNode;
import com.george_vi.electroenergetics.simulation.*;
import com.george_vi.electroenergetics.simulation.electrical_properties.MicroTickingElectricalProperties;
import net.minecraft.core.BlockPos;
import java.util.*;

/** One complete multi-terminal model. Zero-conductance graph edges only preserve connectivity;
 * the full Jacobian and physical residual are stamped by the pinned CEE network extension.
 */
public final class ThreeTerminalDevice<P,T> {
    private static final Map<CircuitBuilder,List<ThreeTerminalDevice<?,?>>> REGISTRY = Collections.synchronizedMap(new WeakHashMap<>());
    public final DeviceModel<P,NoState,T> model;
    public final P parameters;
    public final InWorldNode[] nodes;
    private T trial;
    private TerminalVoltages candidate = new TerminalVoltages(0,0,0);
    private final TimeStep step = new TimeStep(0,0.05); // Models are memoryless; no independent electrical clock.
    public ThreeTerminalDevice(DeviceModel<P,NoState,T> model,P parameters,BlockPos pos) {
        this.model=model;this.parameters=parameters;
        nodes=new InWorldNode[]{new InWorldNode(0,pos),new InWorldNode(1,pos),new InWorldNode(2,pos)};
        trial=model.beginTrial(parameters,NoState.INSTANCE,step);
    }
    public void connect(BridgeCollector bridges) {
        synchronized(REGISTRY) { REGISTRY.computeIfAbsent(bridges.getCircuitBuilder(), k->new ArrayList<>()).add(this); }
        bridges.bridge(nodes[0],nodes[2],new GraphEdge());
        bridges.bridge(nodes[1],nodes[2],new GraphEdge());
    }
    public static List<ThreeTerminalDevice<?,?>> devices(CircuitBuilder builder) {
        synchronized(REGISTRY) { return List.copyOf(REGISTRY.getOrDefault(builder,List.of())); }
    }
    public void beginMicrostep() {
        // Numeric guesses/history never survive a completed or rejected physical microstep.
        candidate=new TerminalVoltages(0,0,0);
        trial=model.beginTrial(parameters,NoState.INSTANCE,step);
    }
    public Linearization linearize() {
        var next=model.linearize(parameters,NoState.INSTANCE,step,candidate,trial);trial=next.trialState();return next.equations();
    }
    public void candidate(TerminalVoltages voltages) { candidate=voltages; }
    public OperatingPoint evaluate(TerminalVoltages voltages) { return model.evaluate(parameters,NoState.INSTANCE,step,voltages); }
    private static final class GraphEdge extends MicroTickingElectricalProperties {
        GraphEdge() { resistance=Double.POSITIVE_INFINITY; }
        @Override public double conductance() { return 0; }
        @Override public void tick(double[] values,int step,int count,int a,int b) {}
    }
}
