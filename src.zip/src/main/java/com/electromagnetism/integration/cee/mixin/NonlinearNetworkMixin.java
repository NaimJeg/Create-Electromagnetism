package com.electromagnetism.integration.cee.mixin;
import com.electromagnetism.integration.cee.electrical.*;
import com.george_vi.electroenergetics.simulation.*;
import com.george_vi.electroenergetics.simulation.simulator.Network;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.*;

@Mixin(value=Network.class,remap=false)
public abstract class NonlinearNetworkMixin implements NonlinearNetworkAccess {
    @Shadow @Final CircuitBuilder builder;
    @Shadow @Final Set<WrappedIndexedNode> allNodes;
    @Shadow Object2IntOpenHashMap<WrappedIndexedNode> nodeIDs;
    @Inject(method="optimize",at=@At("HEAD"),cancellable=true)
    private void electromagnetism$preserveTerminals(CallbackInfo ci) {
        for(var d:ThreeTerminalDevice.devices(builder))
            if(allNodes.contains(builder.getNode(d.nodes[0]))) { ci.cancel();return; }
    }
    @Override public List<Entry> electromagnetism$models() {
        List<Entry> entries=new ArrayList<>();
        for(var d:ThreeTerminalDevice.devices(builder)) {
            if(!allNodes.contains(builder.getNode(d.nodes[0]))) continue;
            int[] indices=new int[3];
            for(int i=0;i<3;i++) {
                var node=builder.getNode(d.nodes[i]);
                if(!nodeIDs.containsKey(node)) throw new IllegalStateException("Nonlinear terminal was eliminated or split");
                indices[i]=nodeIDs.getInt(node);
            }
            entries.add(new Entry(d,indices));
        }
        return entries;
    }
    @Inject(method="formMatrix",at=@At("RETURN"))
    private void electromagnetism$select(CallbackInfo ci) { NonlinearNetworkSolver.select(this); }
}
